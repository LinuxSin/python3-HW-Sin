КОМАНДА ЗАПУСКА КОДА:
python3 test_readers.py --p ./input_data/sar_1_gray.jpg --t img --img ./input_data/sar_1_gray.jpg -o ./output_data/res7.jpg --equalize --gamma 0.2 --mode histogram
